package org.example;

import java.time.LocalDate;
import java.util.UUID;

public class Member {
    int id;
    String name;
    String email;
    LocalDate joindate;

    public Member(UUID id, String name, String email, LocalDate joindate) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.joindate = joindate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getJoindate() {
        return joindate;
    }

    public void setJoindate(LocalDate joindate) {
        this.joindate = joindate;
    }
}
