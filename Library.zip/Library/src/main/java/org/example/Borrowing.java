package org.example;

import java.time.LocalDate;
import java.util.UUID;

public class Borrowing {
    private String bookCode;
    private UUID memberId;
    private LocalDate borrowDate;
    private LocalDate returnDate;

    private String bookTitle;
    private String memberName;

    public Borrowing() {}

    public Borrowing(String bookCode, UUID memberId, LocalDate borrowDate, LocalDate returnDate) {
        this.bookCode = bookCode;
        this.memberId = memberId;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    public String    getBookCode()    { return bookCode; }
    public UUID      getMemberId()    { return memberId; }
    public LocalDate getBorrowDate()  { return borrowDate; }
    public LocalDate getReturnDate()  { return returnDate; }
    public String    getBookTitle()   { return bookTitle; }
    public String    getMemberName()  { return memberName; }

    public void setBookCode(String s)      { this.bookCode = s; }
    public void setMemberId(UUID id)       { this.memberId = id; }
    public void setBorrowDate(LocalDate d) { this.borrowDate = d; }
    public void setReturnDate(LocalDate d) { this.returnDate = d; }
    public void setBookTitle(String s)     { this.bookTitle = s; }
    public void setMemberName(String s)    { this.memberName = s; }
}
