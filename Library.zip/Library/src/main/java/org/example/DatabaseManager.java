package org.example;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.IllformedLocaleException;
import java.util.List;
import java.util.UUID;

public class DatabaseManager {

    private final String url  = "jdbc:postgresql://localhost:5432/library";
    private final String user = "user";
    private final String pass = "123";

    private static DatabaseManager INSTANCE;

    public void initDatabase() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS books (" +
                "code VARCHAR(50) primary key," +
                "title VARCHAR(100) not null," +
                "author VARCHAR(100) not null );" +
                "" +
                "CREATE TABLE IG NOT EXISTS members (" +
                "id UUID primary key defauld gen_random_uuid()," +
                "name varchar(100) not null," +
                "email varchar(100) not null unique," +
                "join_date DATE not null );" +
                "" +
                "CREATE TABLE IF NOT EXISTS borrowings (" +
                "book_code VARCHAR(50) not null," +
                "member_id UUID not null," +
                "borrow_date DATE not null," +
                "return_date DATE," +
                "primary key (book_Code, member_id, borrow_date)," +
                "foreign key (book_code) references books(code) on delete cascade" +
                "foreign key (member_id) references members(id) on delete cascade ); ";

        try (
            Connection connection = getConnection();
            Statement statement = connection.createStatement()) {
                statement.execute(sql);
        }

    }

    private DatabaseManager() {

    }

    public static DatabaseManager getInstance() {
        if (INSTANCE == null)
           INSTANCE = new DatabaseManager();
        return INSTANCE;
    }

    protected Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }

    //books
    //get
    List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        try (
            Connection connection = getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT code, title, author FROM books ORDER BY code")) {
    while (resultSet.next()) {
        books.add(new Book(resultSet.getString("code"),
                resultSet.getString("title"),
                resultSet.getString("author")));
    }
            } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return books;
    }


    //postz
    void addBook(Book book) throws SQLException {
        if (bookExists(book.getCode())) {
            throw new IllegalArgumentException("Book already exists with code: " + book.getCode());
        }
        String sql = "INSERT INTO books (code, title, author) VALUES (?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, book.getCode());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.executeUpdate();
        }
    }

    public boolean bookExists(String code) throws SQLException {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT 1 FROM books WHERE code = ?")) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    //delete
    public void deleteBook(String code) throws SQLException {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM books WHERE code = ?")) {
            ps.setString(1, code);
            ps.executeUpdate();
        }
    }

    //put
    public void updateBook(String code, String title, String author) {
        String sql = "UPDATE books SET title = ?, author = ? WHERE code = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setString(3, code);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    //members
    //get
     List<Member> getallMembers() throws SQLException {
         List<Member> members = new ArrayList<>();
         try (Connection con = getConnection();
              Statement st  = con.createStatement();
              ResultSet rs  = st.executeQuery("SELECT id, name, email, join_date FROM members ORDER BY join_date")) {
             while (rs.next()) {
                 members.add(new Member(
                         UUID.fromString(rs.getString("id")),
                         rs.getString("name"),
                         rs.getString("email"),
                         rs.getDate("join_date").toLocalDate()
                 ));
             }
         }
         return members;
    }

    //put
    public void updateMember(UUID id, String name, String email) throws SQLException {
        String sql = "UPDATE members SET name = ?, email = ? WHERE id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setObject(3, id);
            ps.executeUpdate();
        }
    }

    //delete
    public void deleteMember(UUID id) throws SQLException {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM members WHERE id = ?")) {
            ps.setObject(1, id);
            ps.executeUpdate();
        }
    }

    public boolean emailExists(String email) throws SQLException {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT 1 FROM members WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    //post
    public Member addMember(String name, String email) throws SQLException {
        if (emailExists(email)) {
            throw new IllegalArgumentException("this email already exists : " + email);
        }
        String sql = "INSERT INTO members (name, email) VALUES (?, ?) RETURNING id, join_date";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return new Member(
                        UUID.fromString(rs.getString("id")),
                        name, email,
                        rs.getDate("join_date").toLocalDate()
                );
            }
        }
    }


    //borrowing
    public List<Borrowing> getAllBorrowings() throws SQLException {
        List<Borrowing> borrowings = new ArrayList<>();
        String sql = "SELECT *" +
                "            FROM borrowings br\n" +
                "            JOIN books   b ON b.code = br.book_code\n" +
                "            JOIN members m ON m.id   = br.member_id\n" +
                "            ORDER BY br.borrow_date DESC";
        try (Connection con = getConnection();
             Statement st  = con.createStatement();
             ResultSet rs  = st.executeQuery(sql)) {
            while (rs.next()) {
                Borrowing bw = new Borrowing(
                        rs.getString("book_code"),
                        UUID.fromString(rs.getString("member_id")),
                        rs.getDate("borrow_date").toLocalDate(),
                        rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null
                );
                bw.setBookTitle(rs.getString("book_title"));
                bw.setMemberName(rs.getString("member_name"));
                borrowings.add(bw);
            }
        }
        return borrowings;
    }

    public void borrowBook(String bookCode, UUID memberId) throws SQLException {
        if (isBookBorrowed(bookCode)) {
            throw new IllegalArgumentException("book with code -" + bookCode + "isnt aviable now");
        }
        String sql = "INSERT INTO borrowings (book_code, member_id, borrow_date) VALUES (?, ?, ?)";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, bookCode);
            ps.setObject(2, memberId);
            ps.setDate(3, Date.valueOf(LocalDate.now()));
            ps.executeUpdate();
        }
    }


    public void returnBook(String bookCode) throws SQLException {
        if (!isBookBorrowed(bookCode)) {
            throw new IllegalArgumentException("book coded: " + bookCode + " - isnt borrowed");
        }
        String sql =
                "UPDATE borrowings SET return_date = ? WHERE book_code = ? AND return_date IS NULL";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(LocalDate.now()));
            ps.setString(2, bookCode);
            ps.executeUpdate();
        }
    }


    public boolean isBookBorrowed(String bookCode) throws SQLException {
        String sql = "SELECT 1 FROM borrowings WHERE book_code = ? AND return_date IS NULL";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, bookCode);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
